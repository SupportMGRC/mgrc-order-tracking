@extends('layouts.master')

@section('content')
    <style>
        .customer-dropdown .dropdown-menu {
            max-height: 300px;
            overflow-y: auto;
            width: 100%;
        }
        .customer-dropdown .dropdown-item {
            padding: 0.5rem 1rem;
            white-space: normal;
            cursor: pointer;
        }
        .customer-dropdown .dropdown-item:hover {
            background-color: #f8f9fa;
        }
        .search-customer:focus {
            box-shadow: none;
        }
        .dropdown-menu-list {
            padding: 0;
            margin: 0;
        }
        .dropdown-menu-list li {
            border-bottom: 1px solid #f0f0f0;
        }
        .dropdown-menu-list li:last-child {
            border-bottom: none;
        }
        .new-customer-option {
            background-color: #f8f9fa;
            font-weight: 500;
        }
    </style>
    

    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">New Order</h4>
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="{{ route('orderhistory') }}">Orders</a></li>
                        <li class="breadcrumb-item active">New Order</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if(session('error'))
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        {{ session('error') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    @if ($errors->any())
    <div class="alert alert-danger alert-border-left alert-dismissible fade show" role="alert">
        <i class="ri-error-warning-line me-3 align-middle fs-16"></i><strong>Validation Error!</strong> Please check the form and try again.
        <ul class="mb-0 mt-2">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

    <div class="row">
        <div class="col-12">
            <!-- Info box showing who will be recorded as placing the order -->
            <div class="alert alert-info alert-border-left d-flex align-items-center" role="alert">
                <i class="ri-information-line me-3 align-middle fs-16"></i>
                <div>
                    <strong>Order Tracking:</strong> This order will be recorded as placed by <strong>{{ Auth::user()->username }}</strong>
                </div>
            </div>
            <div class="card">
                <div class="card-body checkout-tab">
                    <form action="{{ route('neworder.store') }}" method="POST" id="orderForm" novalidate>
                        @csrf
                        
                        <!-- Hidden field to automatically capture who placed the order -->
                        <input type="hidden" name="order_placed_by" value="{{ Auth::user()->username }}">
                        
                        
                        
                        <div class="step-arrow-nav mt-n3 mx-n3 mb-3">
                            <ul class="nav nav-pills nav-justified custom-nav bg-warning bg-opacity-75" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link fs-15 p-3 text-black active" id="pills-bill-info-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-bill-info" type="button" role="tab"
                                        aria-controls="pills-bill-info" aria-selected="true">
                                        <i class="ri-user-2-line fs-16 p-2 bg-warning text-black rounded-circle align-middle me-2"></i>
                                        Customer Details
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link fs-15 p-3 text-black" id="pills-bill-address-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-bill-address" type="button" role="tab"
                                        aria-controls="pills-bill-address" aria-selected="false">
                                        <i class="ri-truck-line fs-16 p-2 bg-warning text-black rounded-circle align-middle me-2"></i>
                                        Order Details
                                    </button>
                                </li>
                            </ul>
                        </div>

                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="pills-bill-info" role="tabpanel" aria-labelledby="pills-bill-info-tab">
                                <div>
                                    <h5 class="mb-1">Customer Information</h5>
                                    <p class="text-muted mb-4">Please fill all information below</p>
                                </div>

                                <div>
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <label for="customer_name" class="form-label">Customer Name <span class="text-danger">*</span></label>
                                            <div class="dropdown customer-dropdown">
                                                <input type="text" class="form-control search-customer @error('customer_name') is-invalid @enderror" 
                                                    id="customer_name" name="customer_name" 
                                                    placeholder="Type to search or enter new customer name" 
                                                    data-bs-toggle="dropdown" aria-expanded="false" 
                                                    autocomplete="off" 
                                                    value="{{ old('customer_name') }}" required />
                                                <input type="hidden" id="customer_id" name="customer_id" value="{{ old('customer_id') }}">
                                                <div class="dropdown-menu w-100">
                                                    <ul class="list-unstyled dropdown-menu-list mb-0" id="customer_list">
                                                        <li>
                                                            <a class="dropdown-item new-customer-option" href="#" 
                                                                data-id="" data-name="" data-email="" data-phone="" data-address="">
                                                                <i class="ri-add-line align-middle me-2"></i>Enter New Customer
                                                            </a>
                                                        </li>
                                                        @foreach($customers as $customer)
                                                            <li>
                                                                <a class="dropdown-item customer-option" href="#" 
                                                                    data-id="{{ $customer->id }}"
                                                                    data-name="{{ $customer->name }}"
                                                                    data-email="{{ $customer->email }}"
                                                                    data-phone="{{ $customer->phoneNo }}"
                                                                    data-address="{{ $customer->address }}">
                                                                    <span class="fw-medium">{{ $customer->name }}</span> 
                                                                    <small class="text-muted">{{ $customer->phoneNo }}</small>
                                                                </a>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            </div>
                                            @error('customer_name')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="invalid-feedback">Please enter the customer name</div>
                                            <div class="form-text">Type to search existing customers or enter a new customer name</div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 col-12">
                                            <div class="mb-3">
                                                <label for="customer_email" class="form-label">Email <span class="text-muted">(Optional)</span></label>
                                                <input type="email" class="form-control @error('customer_email') is-invalid @enderror" 
                                                    id="customer_email" name="customer_email" placeholder="Enter email"
                                                    value="{{ old('customer_email') }}">
                                                @error('customer_email')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="mb-3">
                                                <label for="customer_phone" class="form-label">Phone <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control @error('customer_phone') is-invalid @enderror" 
                                                    id="customer_phone" name="customer_phone" placeholder="Enter phone no."
                                                    value="{{ old('customer_phone') }}" required>
                                                @error('customer_phone')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                                <div class="invalid-feedback">Please enter a phone number</div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="customer_address" class="form-label">Address <span class="text-danger">*</span></label>
                                        <textarea class="form-control @error('customer_address') is-invalid @enderror" 
                                            id="customer_address" name="customer_address" placeholder="Enter address" 
                                            rows="3" required>{{ old('customer_address') }}</textarea>
                                        @error('customer_address')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                        <div class="invalid-feedback">Please enter the customer address</div>
                                    </div>

                                                                    <div class="d-flex flex-column flex-sm-row align-items-start gap-3 mt-3">
                                    <button type="button" class="btn btn-success btn-label right ms-auto nexttab w-100 w-sm-auto"
                                        data-nexttab="pills-bill-address-tab">
                                        <i class="ri-arrow-right-line label-icon align-middle fs-16 ms-2"></i>
                                        Next to Order Details
                                    </button>
                                </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="pills-bill-address" role="tabpanel" aria-labelledby="pills-bill-address-tab">
                                <div>
                                    <h5 class="mb-1">Order Details</h5>
                                    <p class="text-muted mb-4">Please fill all information below</p>
                                    <div class="alert alert-info alert-border-left mb-4" role="alert">
                                        <i class="ri-information-line me-2"></i>
                                        <strong>Note:</strong> For "Infusion Set" products, only quantity is required. Patient name and remarks fields will be disabled.
                                    </div>
                                </div>

                                <div class="order-items mb-3">
                                    <div class="order-item p-2 border rounded bg-light shadow-sm mb-3">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-2 gap-2">
                                                    <h6 class="text-primary mb-0"><i class="ri-medicine-bottle-line me-1"></i>Order Item</h6>
                                                    <div>
                                                        <button type="button" class="btn btn-sm btn-danger shadow-sm delete-item" data-item-id="0">
                                                            <i class="ri-delete-bin-line me-1"></i><span class="d-none d-sm-inline">Remove</span><span class="d-sm-none">Remove</span>
                                                        </button>
                                                    </div>
                                                </div>
                                                <hr class="mt-1 mb-3">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-12">
                                                <div class="mb-3">
                                                    <label for="products[0][type]" class="form-label fw-semibold">Order Type <span class="text-danger">*</span></label>
                                                    <select class="form-select order-type shadow-sm @error('products.0.type') is-invalid @enderror" 
                                                        id="products[0][type]" name="products[0][type]" required>
                                                        <option value="">Select Order Type...</option>
                                                        @foreach($products as $product)
                                                            <option value="{{ $product->name }}" {{ old('products.0.type') == $product->name ? 'selected' : '' }}>
                                                                {{ $product->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    @error('products.0.type')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                    <div class="invalid-feedback">Please select an order type</div>
                                                </div>
                                            </div>
                                            <div class="col-lg-4 col-sm-8 col-12">
                                                <div class="mb-3">
                                                    <label for="products[0][patient_name]" class="form-label fw-semibold">Patient Name</label>
                                                    <input type="text" class="form-control patient-name-field @error('products.0.patient_name') is-invalid @enderror" 
                                                        id="products[0][patient_name]" name="products[0][patient_name]" 
                                                        placeholder="Enter patient name" value="{{ old('products.0.patient_name') }}">
                                                    @error('products.0.patient_name')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-lg-2 col-sm-4 col-12">
                                                <div class="mb-3">
                                                    <label for="products[0][quantity]" class="form-label fw-semibold">Quantity <span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control @error('products.0.quantity') is-invalid @enderror" 
                                                        id="products[0][quantity]" name="products[0][quantity]" 
                                                        value="{{ old('products.0.quantity', 1) }}" min="1" max="100"
                                                        onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                                    @error('products.0.quantity')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                    <div class="invalid-feedback">Please enter a quantity</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-10 col-sm-8 col-12">
                                                <div class="mb-0">
                                                    <label for="products[0][remarks]" class="form-label fw-semibold">Remarks</label>
                                                    <textarea class="form-control remarks-field @error('products.0.remarks') is-invalid @enderror" 
                                                        id="products[0][remarks]" name="products[0][remarks]" 
                                                        placeholder="Enter any remarks for this order item" rows="2">{{ old('products.0.remarks') }}</textarea>
                                                    @error('products.0.remarks')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                            <div class="col-lg-2 col-sm-4 col-12">
                                                <div class="mb-3">
                                                    <label class="form-label fw-semibold d-block">&nbsp;</label>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" 
                                                            id="products[0][coa_required]" 
                                                            name="products[0][coa_required]" 
                                                            value="1"
                                                            {{ old('products.0.coa_required') ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="products[0][coa_required]">
                                                            COA Required
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <button type="button" class="btn btn-info btn-sm shadow-sm" id="add-more-items">
                                        <i class="ri-add-line align-middle me-1"></i> Add More Items
                                    </button>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <label for="delivery_address" class="form-label">Delivery Address <span class="text-danger" id="delivery_address_required">*</span></label>
                                            <textarea class="form-control @error('delivery_address') is-invalid @enderror" id="delivery_address" name="delivery_address" placeholder="Enter delivery address" rows="2" required>{{ old('delivery_address') }}</textarea>
                                            @error('delivery_address')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="invalid-feedback">Please enter the delivery address</div>
                                            <div class="form-text">Required for Delivery. Optional for Self Collect.</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <div class="row">
                                                <div class="col-lg-6 col-12">
                                                    <label class="form-label d-block">Delivery Type <span class="text-danger">*</span></label>
                                                    <div class="d-flex flex-column flex-sm-row gap-3 gap-sm-4">
                                                        <div class="form-check">
                                                            <input class="form-check-input" 
                                                                type="radio" 
                                                                name="delivery_type" 
                                                                id="delivery_type_delivery" 
                                                                value="delivery" 
                                                                {{ old('delivery_type', 'delivery') == 'delivery' ? 'checked' : '' }}>
                                                            <label class="form-check-label" for="delivery_type_delivery">
                                                                <i class="ri-truck-line me-1"></i>Delivery
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" 
                                                                type="radio" 
                                                                name="delivery_type" 
                                                                id="delivery_type_self" 
                                                                value="self_collect"
                                                                {{ old('delivery_type') == 'self_collect' ? 'checked' : '' }}>
                                                            <label class="form-check-label" for="delivery_type_self">
                                                                <i class="ri-user-location-line me-1"></i>Self Collect
                                                            </label>
                                                        </div>
                                                    </div>
                                                    @error('delivery_type')
                                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                                <div class="col-lg-6 col-12">
                                                    <label class="form-label d-block">Time Sensitive Order</label>
                                                    <div class="form-check form-check-lg">
                                                        <input class="form-check-input" type="checkbox" name="time_sensitive" id="time_sensitive" value="1" {{ old('time_sensitive') ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="time_sensitive">
                                                            <i class="ri-time-line me-1"></i>Mark as Time Sensitive
                                                        </label>
                                                    </div>
                                                    <small class="text-muted">Check this box if the order is time sensitive</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-12">
                                        <div class="mb-3">
                                            <div class="row">
                                                <div class="col-lg-6 col-12">
                                                    <label for="item_ready_at" class="form-label">Item Ready Time <span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control @error('item_ready_at') is-invalid @enderror" id="item_ready_at" name="item_ready_at" placeholder="e.g. 02:30 PM" data-provider="flatpickr" data-enable-time="true" data-no-calendar="true" data-date-format="h:i K" value="{{ old('item_ready_at') }}" required>
                                                    @error('item_ready_at')
                                                        <div class="invalid-feedback">{{ $message }}</div>
                                                    @enderror
                                                    <div class="invalid-feedback">Please select the item ready time</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="collection_date" class="form-label">Collection Date <span class="text-muted">(Optional)</span></label>
                                            <input type="text" class="form-control @error('collection_date') is-invalid @enderror" 
                                                id="collection_date" name="collection_date" 
                                                data-provider="flatpickr" data-date-format="Y-m-d" 
                                                value="{{ old('collection_date') }}" placeholder="Select collection date (optional)">
                                            @error('collection_date')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="form-text">Optional: Date when order was collected from supplier/lab</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="collection_time" class="form-label">Collection Time <span class="text-muted">(Optional)</span></label>
                                            <input type="text" class="form-control @error('collection_time') is-invalid @enderror" 
                                                id="collection_time" name="collection_time" 
                                                placeholder="e.g. 02:30 PM" 
                                                value="{{ old('collection_time') }}">
                                            @error('collection_time')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="form-text">Optional: Time when order was collected</div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="pickup_delivery_date" class="form-label"><span id="date_label">Delivery</span> Date <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control @error('pickup_delivery_date') is-invalid @enderror" 
                                                id="pickup_delivery_date" name="pickup_delivery_date" 
                                                data-provider="flatpickr" data-date-format="Y-m-d" 
                                                value="{{ old('pickup_delivery_date') }}" required>
                                            @error('pickup_delivery_date')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="invalid-feedback">Please select a date</div>
                                            @if(!empty($blockedDatesWithReasons) && count($blockedDatesWithReasons) > 0)
                                                <div class="form-text text-warning">
                                                    <i class="ri-information-line me-1"></i>
                                                    <strong>Note:</strong> Some dates are not available for orders
                                                    <button type="button" class="btn btn-link btn-sm p-0 ms-1" data-bs-toggle="modal" data-bs-target="#blockedDatesModal">
                                                        View blocked dates
                                                    </button>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="pickup_delivery_time" class="form-label"><span id="time_label">Reach Client</span> Time <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control @error('pickup_delivery_time') is-invalid @enderror" 
                                                id="pickup_delivery_time" name="pickup_delivery_time" 
                                                data-provider="timepickr" 
                                                placeholder="Select time"
                                                value="{{ old('pickup_delivery_time') }}" required>
                                            @error('pickup_delivery_time')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <div class="invalid-feedback">Please select a time</div>
                                            {{-- <small class="text-muted">Time reach at client</small> --}}
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="remarks" class="form-label">General Remarks</label>
                                    <textarea class="form-control @error('remarks') is-invalid @enderror" 
                                        id="remarks" name="remarks" placeholder="Enter any general remarks for the entire order" 
                                        rows="3">{{ old('remarks') }}</textarea>
                                    @error('remarks')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="d-flex flex-column flex-sm-row align-items-start gap-3 mt-3">
                                    <button type="button" class="btn btn-light btn-label previestab w-100 w-sm-auto"
                                        data-previous="pills-bill-info-tab">
                                        <i class="ri-arrow-left-line label-icon align-middle fs-16 me-2"></i>
                                        Back to Customer Details
                                    </button>
                                    <button type="button" id="saveOrderBtn" class="btn btn-success btn-label right ms-auto w-100 w-sm-auto">
                                        <i class="ri-save-line label-icon align-middle fs-16 ms-2"></i>
                                        Save Order
                                    </button>
                                </div>
                            </div>
                        </div>
                        <!-- end tab content -->
                    </form>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->

    <!-- Blocked Dates Modal -->
    @if(!empty($blockedDatesWithReasons) && count($blockedDatesWithReasons) > 0)
    <div class="modal fade" id="blockedDatesModal" tabindex="-1" aria-labelledby="blockedDatesModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="blockedDatesModalLabel">
                        <i class="ri-calendar-event-line me-2"></i>Blocked Dates
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">The following dates are not available for placing orders:</p>
                    <div class="list-group">
                        @foreach($blockedDatesWithReasons as $blockedDate)
                            <div class="list-group-item d-flex justify-content-between align-items-start">
                                <div class="me-auto">
                                    <div class="fw-bold text-danger">{{ $blockedDate['formatted_date'] }}</div>
                                    <small class="text-muted">{{ $blockedDate['reason'] }}</small>
                                </div>
                                <span class="badge bg-secondary rounded-pill">{{ ucfirst($blockedDate['type']) }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Order Confirmation Modal -->
    <div class="modal fade" id="orderConfirmationModal" tabindex="-1" aria-labelledby="orderConfirmationModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-black">
                    <h5 class="modal-title" id="orderConfirmationModalLabel">
                        <i class="ri-clipboard-line me-2"></i>Confirm Order Details
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body py-3">
                    <div class="alert alert-info alert-border-left mb-3">
                        <i class="ri-information-line me-2"></i>
                        <strong>Please review your order details carefully before confirming.</strong>
                    </div>
                    
                    <!-- Customer Information -->
                    <div class="mb-3">
                        <h6 class="fw-bold text-dark mb-2">
                            <i class="ri-user-2-line me-2"></i>Customer Information
                        </h6>
                        <div class="border p-3 rounded bg-light">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Name:</strong> <span id="confirm-customer-name">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Phone:</strong> <span id="confirm-customer-phone">-</span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>Email:</strong> <span id="confirm-customer-email">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Address:</strong> <span id="confirm-customer-address">-</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Order Items -->
                    <div class="mb-3">
                        <h6 class="fw-bold text-dark mb-2">
                            <i class="ri-medicine-bottle-line me-2"></i>Order Items
                        </h6>
                        <div id="confirm-order-items" class="border p-3 rounded bg-light">
                            <!-- Order items will be populated here -->
                        </div>
                    </div>

                    <!-- Delivery Information -->
                    <div class="mb-3">
                        <h6 class="fw-bold text-dark mb-2">
                            <i class="ri-truck-line me-2"></i>Delivery Information
                        </h6>
                        <div class="border p-3 rounded bg-light">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Type:</strong> <span id="confirm-delivery-type">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Time Sensitive:</strong> <span id="confirm-time-sensitive" class="badge bg-danger">No</span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>Date:</strong> <span id="confirm-delivery-date">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Time:</strong> <span id="confirm-delivery-time">-</span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>Item Ready:</strong> <span id="confirm-item-ready">-</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Address:</strong> <span id="confirm-delivery-address">-</span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6">
                                    <strong>Collection Date:</strong> <span id="confirm-collection-date">Not specified</span>
                                </div>
                                <div class="col-md-6">
                                    <strong>Collection Time:</strong> <span id="confirm-collection-time">Not specified</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- General Remarks -->
                    <div class="mb-2">
                        <h6 class="fw-bold text-dark mb-2">
                            <i class="ri-chat-3-line me-2"></i>General Remarks
                        </h6>
                        <div class="border p-3 rounded bg-light">
                            <span id="confirm-general-remarks">No remarks</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer py-2">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="ri-close-line me-1"></i>Cancel
                    </button>
                    <button type="button" id="confirmOrderBtn" class="btn btn-success">
                        <i class="ri-check-line me-1"></i>Confirm & Place Order
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Minimal JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize date and time pickers
            if (typeof flatpickr !== 'undefined') {
                // Get blocked dates from PHP
                const blockedDates = @json($blockedDates);
                
                flatpickr("#pickup_delivery_date", {
                    dateFormat: "Y-m-d",
                    minDate: "today",
                    allowInput: true,
                    disable: [
                        function(date) {
                            // Convert date to YYYY-MM-DD format
                            const dateStr = date.toLocaleDateString('en-CA', {
                                year: 'numeric', 
                                month: '2-digit', 
                                day: '2-digit'
                            }).replace(/\//g, '-');
                            return blockedDates.includes(dateStr);
                        }
                    ],
                    onDayCreate: function(dObj, dStr, fp, dayElem) {
                        // Add visual indication for blocked dates
                        const dateStr = dayElem.dateObj.toLocaleDateString('en-CA', {
                            year: 'numeric', 
                            month: '2-digit', 
                            day: '2-digit'
                        }).replace(/\//g, '-');
                        
                        if (blockedDates.includes(dateStr)) {
                            dayElem.classList.add('blocked-date');
                            dayElem.style.backgroundColor = '#ffebee';
                            dayElem.style.color = '#c62828';
                            dayElem.style.cursor = 'not-allowed';
                            dayElem.title = 'This date is not available for orders';
                        }
                    },
                    // Prevent selecting blocked dates
                    onChange: function(selectedDates, dateStr, instance) {
                        // Use the same date format as backend
                        const formattedDate = selectedDates[0] ? 
                            selectedDates[0].toLocaleDateString('en-CA', {
                                year: 'numeric', 
                                month: '2-digit', 
                                day: '2-digit'
                            }).replace(/\//g, '-') : 
                            null;
                        
                        if (formattedDate && blockedDates.includes(formattedDate)) {
                            instance.clear();
                            Toastify({
                                text: "Selected date is not available for orders.",
                                duration: 3000,
                                close: true,
                                gravity: "top",
                                position: "right",
                                backgroundColor: "#d32f2f",
                            }).showToast();
                        }
                    }
                });
                
                // Collection date picker (optional, no restrictions)
                flatpickr("#collection_date", {
                    dateFormat: "Y-m-d",
                    allowInput: true
                });
                
                flatpickr("#pickup_delivery_time", {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "h:i K",
                    time_24hr: false,
                    minuteIncrement: 15,
                    allowInput: true
                });
                flatpickr("#item_ready_at", {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "h:i K",
                    time_24hr: false,
                    allowInput: true,
                    altInput: false
                });
                
                flatpickr("#collection_time", {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "h:i K",
                    time_24hr: false,
                    allowInput: true,
                    altInput: false
                });
            }
            
            // Customer search functionality
            const customerSearchInput = document.getElementById('customer_name');
            const customerList = document.getElementById('customer_list');
            
            // Initialize Bootstrap dropdown
            const dropdownElementList = [].slice.call(document.querySelectorAll('[data-bs-toggle="dropdown"]'));
            const dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
                return new bootstrap.Dropdown(dropdownToggleEl);
            });
            
            // Filter customers in dropdown as user types
            customerSearchInput.addEventListener('input', function(e) {
                const searchText = e.target.value.toLowerCase();
                const customerItems = customerList.querySelectorAll('li');
                let resultsFound = false;
                
                // Always show "Enter New Customer" option
                const newCustomerOption = document.querySelector('.new-customer-option');
                if (newCustomerOption) {
                    newCustomerOption.setAttribute('data-name', searchText);
                }
                
                customerItems.forEach(function(item) {
                    if (item.querySelector('.new-customer-option')) {
                        item.style.display = 'block';
                        return;
                    }
                    
                    const customerOption = item.querySelector('.customer-option');
                    const customerName = customerOption.getAttribute('data-name').toLowerCase();
                    const customerPhone = customerOption.getAttribute('data-phone') ? 
                        customerOption.getAttribute('data-phone').toLowerCase() : '';
                    
                    const shouldDisplay = (customerName.includes(searchText) || customerPhone.includes(searchText));
                    item.style.display = shouldDisplay ? 'block' : 'none';
                    
                    if (shouldDisplay) resultsFound = true;
                });
                
                // Automatically show dropdown when typing
                if (searchText.length > 0) {
                    const dropdownInstance = bootstrap.Dropdown.getInstance(customerSearchInput);
                    if (!dropdownInstance._isShown()) {
                        dropdownInstance.show();
                    }
                }
                
                // Update "Enter New Customer" option text
                if (searchText.length > 0) {
                    const newCustomerLink = document.querySelector('.new-customer-option');
                    if (newCustomerLink) {
                        newCustomerLink.innerHTML = `<i class="ri-add-line align-middle me-2"></i>Add "${searchText}" as new customer`;
                    }
                } else {
                    const newCustomerLink = document.querySelector('.new-customer-option');
                    if (newCustomerLink) {
                        newCustomerLink.innerHTML = `<i class="ri-add-line align-middle me-2"></i>Enter New Customer`;
                    }
                }
                
                // Add no results message if needed
                const noResultsMsg = document.getElementById('no-results-msg');
                if (!resultsFound && searchText.length > 0) {
                    if (!noResultsMsg) {
                        const msgItem = document.createElement('li');
                        msgItem.id = 'no-results-msg';
                        msgItem.className = 'px-3 py-2 text-center text-muted small';
                        msgItem.textContent = 'No matches found';
                        customerList.appendChild(msgItem);
                    }
                } else if (noResultsMsg) {
                    noResultsMsg.remove();
                }
                
                // Validate the field since it's required
                validateField(customerSearchInput);
            });
            
            // Handle customer selection from dropdown
            customerList.addEventListener('click', function(e) {
                e.preventDefault();
                const target = e.target.closest('.dropdown-item');
                if (!target) return;
                
                let customerId = target.getAttribute('data-id');
                let customerName = target.getAttribute('data-name');
                const customerEmail = target.getAttribute('data-email');
                const customerPhone = target.getAttribute('data-phone');
                const customerAddress = target.getAttribute('data-address');
                
                // If new customer option was clicked, use the search input value as the name
                if (target.classList.contains('new-customer-option')) {
                    customerName = customerSearchInput.value;
                    document.getElementById('customer_id').value = '';
                } else {
                    document.getElementById('customer_id').value = customerId;
                }
                
                // Update name field (which is now the same as the search field)
                customerSearchInput.value = customerName;
                
                // If using an existing customer, populate email, phone and address fields
                document.getElementById('customer_email').value = customerEmail || '';
                document.getElementById('customer_phone').value = customerPhone || '';
                document.getElementById('customer_address').value = customerAddress || '';
                
                // Validate fields
                validateField(customerSearchInput);
                if (customerPhone) validateField(document.getElementById('customer_phone'));
                if (customerAddress) validateField(document.getElementById('customer_address'));
                
                // Close dropdown
                const dropdownInstance = bootstrap.Dropdown.getInstance(customerSearchInput);
                if (dropdownInstance) {
                    dropdownInstance.hide();
                }
            });
            
            // Tab navigation
            document.querySelector('.nexttab').addEventListener('click', function() {
                const customerTab = document.getElementById('pills-bill-info');
                const requiredFields = customerTab.querySelectorAll('[required]');
                let errors = [];
                
                requiredFields.forEach(function(field) {
                    if (!validateField(field)) {
                        let fieldName = field.getAttribute('placeholder') || 
                                       field.previousElementSibling?.textContent || 
                                       'Field';
                        fieldName = fieldName.replace(/\*|\(.*?\)/g, '').trim();
                        errors.push(`${fieldName} is required.`);
                    }
                });
                
                if (errors.length === 0) {
                    const nextTabId = this.getAttribute('data-nexttab');
                    document.getElementById(nextTabId).click();
                } else {
                    showValidationAlert(errors);
                }
            });
            
            document.querySelectorAll('.previestab').forEach(function(button) {
                button.addEventListener('click', function() {
                    const prevTabId = this.getAttribute('data-previous');
                    document.getElementById(prevTabId).click();
                });
            });
            
            // Add more items functionality
            let itemCount = 0;
            document.getElementById('add-more-items').addEventListener('click', function() {
                itemCount++;
                const newItem = document.createElement('div');
                newItem.className = 'order-item p-2 border rounded bg-light shadow-sm mb-3';
                newItem.innerHTML = `
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center mb-2 gap-2">
                                <h6 class="text-primary mb-0"><i class="ri-medicine-bottle-line me-1"></i>Order Item</h6>
                                <div>
                                    <button type="button" class="btn btn-sm btn-danger shadow-sm delete-item" data-item-id="${itemCount}">
                                        <i class="ri-delete-bin-line me-1"></i><span class="d-none d-sm-inline">Remove</span><span class="d-sm-none">Remove</span>
                                    </button>
                                </div>
                            </div>
                            <hr class="mt-1 mb-3">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="mb-3">
                                <label for="products[${itemCount}][type]" class="form-label fw-semibold">Order Type <span class="text-danger">*</span></label>
                                <select class="form-select order-type shadow-sm" id="products[${itemCount}][type]" name="products[${itemCount}][type]" required>
                                    <option value="">Select Order Type...</option>
                                    @foreach($products as $product)
                                        <option value="{{ $product->name }}">{{ $product->name }}</option>
                                    @endforeach
                                </select>
                                <div class="invalid-feedback">Please select an order type</div>
                            </div>
                        </div>
                                                                <div class="col-lg-4 col-sm-8 col-12">
                                            <div class="mb-3">
                                                <label for="products[${itemCount}][patient_name]" class="form-label fw-semibold">Patient Name</label>
                                                <input type="text" class="form-control patient-name-field" id="products[${itemCount}][patient_name]" name="products[${itemCount}][patient_name]" placeholder="Enter patient name">
                                            </div>
                                        </div>
                        <div class="col-lg-2 col-sm-4 col-12">
                            <div class="mb-3">
                                <label for="products[${itemCount}][quantity]" class="form-label fw-semibold">Quantity <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="products[${itemCount}][quantity]" name="products[${itemCount}][quantity]" value="1" min="1" max="100" onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                <div class="invalid-feedback">Please enter a quantity</div>
                            </div>
                        </div>
                    </div>
                                                        <div class="row">
                                        <div class="col-lg-10 col-sm-8 col-12">
                                            <div class="mb-0">
                                                <label for="products[${itemCount}][remarks]" class="form-label fw-semibold">Remarks</label>
                                                <textarea class="form-control remarks-field" id="products[${itemCount}][remarks]" name="products[${itemCount}][remarks]" placeholder="Enter any remarks for this order item" rows="2"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-sm-4 col-12">
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold d-block">&nbsp;</label>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" 
                                                        id="products[${itemCount}][coa_required]" 
                                                        name="products[${itemCount}][coa_required]" 
                                                        value="1">
                                                    <label class="form-check-label" for="products[${itemCount}][coa_required]">
                                                        COA Required
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                `;
                document.querySelector('.order-items').appendChild(newItem);
                
                const newSelect = newItem.querySelector('select');
                const newQuantity = newItem.querySelector('input[type="number"]');
                
                newSelect.addEventListener('change', function() {
                    validateField(this);
                    handleInfusionSetLogic(this);
                });
                
                newQuantity.addEventListener('change', function() {
                    validateField(this);
                });
            });
            
            // Delete item functionality
            document.addEventListener('click', function(e) {
                if (e.target.closest('.delete-item')) {
                    const itemElement = e.target.closest('.order-item');
                    if (document.querySelectorAll('.order-item').length > 1) {
                        itemElement.remove();
                    } else {
                        showValidationAlert('You need at least one product item. Cannot remove the last product.');
                        const productSection = itemElement.querySelector('select');
                        if (productSection) {
                            productSection.focus();
                        }
                    }
                }
            });
            
            // Field validation
            function validateField(field) {
                if (!field.checkValidity()) {
                    field.classList.add('is-invalid');
                    return false;
                } else {
                    field.classList.remove('is-invalid');
                    field.classList.add('is-valid');
                    return true;
                }
            }
            
            // Show validation alert
            function showValidationAlert(message) {
                const existingAlerts = document.querySelectorAll('.validation-alert');
                existingAlerts.forEach(function(alert) {
                    alert.remove();
                });
                
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-danger alert-border-left alert-dismissible fade show validation-alert';
                
                if (Array.isArray(message)) {
                    let messageHtml = `
                        <i class="ri-error-warning-line me-3 align-middle fs-16"></i>
                        <strong>Validation Error!</strong> Please check the form and try again.
                        <ul class="mb-0 my-5">
                    `;
                    
                    message.forEach(item => {
                        messageHtml += `<li>${item}</li>`;
                    });
                    
                    messageHtml += '</ul>';
                    alertDiv.innerHTML = messageHtml;
                } else {
                    alertDiv.innerHTML = `
                        <i class="ri-error-warning-line me-3 align-middle fs-16"></i>
                        <strong>Validation Error!</strong> ${message}
                    `;
                }
                
                const closeButton = document.createElement('button');
                closeButton.type = 'button';
                closeButton.className = 'btn-close';
                closeButton.setAttribute('data-bs-dismiss', 'alert');
                closeButton.setAttribute('aria-label', 'Close');
                alertDiv.appendChild(closeButton);
                
                const cardRow = document.querySelector('.card').closest('.row');
                cardRow.parentNode.insertBefore(alertDiv, cardRow);
                
                window.scrollTo({
                    top: alertDiv.offsetTop - 20,
                    behavior: 'smooth'
                });
            }
            
            // Function to handle Infusion Set logic
            function handleInfusionSetLogic(selectElement) {
                const orderItem = selectElement.closest('.order-item');
                const patientNameField = orderItem.querySelector('.patient-name-field');
                const remarksField = orderItem.querySelector('.remarks-field');
                
                if (selectElement.value === 'Infusion Set') {
                    // Disable patient name and remarks fields
                    if (patientNameField) {
                        patientNameField.disabled = true;
                        patientNameField.value = '';
                        patientNameField.style.backgroundColor = '#f8f9fa';
                        patientNameField.placeholder = 'Not required for Infusion Set';
                    }
                    if (remarksField) {
                        remarksField.disabled = true;
                        remarksField.value = '';
                        remarksField.style.backgroundColor = '#f8f9fa';
                        remarksField.placeholder = 'Not required for Infusion Set';
                    }
                } else {
                    // Enable patient name and remarks fields
                    if (patientNameField) {
                        patientNameField.disabled = false;
                        patientNameField.style.backgroundColor = '';
                        patientNameField.placeholder = 'Enter patient name';
                    }
                    if (remarksField) {
                        remarksField.disabled = false;
                        remarksField.style.backgroundColor = '';
                        remarksField.placeholder = 'Enter any remarks for this order item';
                    }
                }
            }

            // Add change listener to existing order type select
            document.querySelector('select[name="products[0][type]"]').addEventListener('change', function() {
                handleInfusionSetLogic(this);
            });

            // Phone number duplicate check
            document.getElementById('customer_phone').addEventListener('input', function() {
                checkDuplicatePhone(this.value);
            });

            function checkDuplicatePhone(phoneNumber) {
                if (phoneNumber.length < 8) return; // Only check when phone has reasonable length
                
                // Get all customers data
                const customers = @json($customers);
                const existingCustomer = customers.find(customer => 
                    customer.phoneNo === phoneNumber
                );
                
                if (existingCustomer) {
                    // Show warning and auto-populate
                    showDuplicateCustomerWarning(existingCustomer);
                } else {
                    // Remove any existing warnings
                    removeDuplicateCustomerWarning();
                }
            }

            function showDuplicateCustomerWarning(customer) {
                // Remove existing warning first
                removeDuplicateCustomerWarning();
                
                // Create warning alert
                const warningDiv = document.createElement('div');
                warningDiv.id = 'duplicate-customer-warning';
                warningDiv.className = 'alert alert-danger alert-border-left mt-2 mb-0';
                warningDiv.innerHTML = `
                    <div>
                        <i class="ri-error-warning-line me-2"></i>
                        <strong>Customer Already Exists!</strong> 
                        <span>This phone number belongs to: <strong>${customer.name}</strong></span>
                    </div>
                `;
                
                // Insert after phone field
                const phoneField = document.getElementById('customer_phone');
                phoneField.parentNode.insertBefore(warningDiv, phoneField.nextSibling);
            }

            function removeDuplicateCustomerWarning() {
                const existingWarning = document.getElementById('duplicate-customer-warning');
                if (existingWarning) {
                    existingWarning.remove();
                }
            }

            // Make useExistingCustomer function global
            window.useExistingCustomer = function(id, name, email, phone, address) {
                // Populate all fields with existing customer data
                document.getElementById('customer_id').value = id;
                document.getElementById('customer_name').value = name;
                document.getElementById('customer_email').value = email;
                document.getElementById('customer_phone').value = phone;
                document.getElementById('customer_address').value = address;
                
                // Validate fields
                validateField(document.getElementById('customer_name'));
                validateField(document.getElementById('customer_phone'));
                validateField(document.getElementById('customer_address'));
                
                // Remove warning
                removeDuplicateCustomerWarning();
                
                // Show success message
                showSuccessMessage('Customer information loaded successfully!');
            };

            function showSuccessMessage(message) {
                // Remove existing success messages
                const existingSuccess = document.querySelectorAll('.success-message');
                existingSuccess.forEach(msg => msg.remove());
                
                const successDiv = document.createElement('div');
                successDiv.className = 'alert alert-success alert-dismissible fade show success-message mt-2';
                successDiv.innerHTML = `
                    <i class="ri-check-line me-2"></i>${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;
                
                const phoneField = document.getElementById('customer_phone');
                phoneField.parentNode.insertBefore(successDiv, phoneField.nextSibling);
                
                // Auto-dismiss after 3 seconds
                setTimeout(() => {
                    if (successDiv && successDiv.parentNode) {
                        successDiv.remove();
                    }
                }, 3000);
            }

            // Add validation listeners to all required fields
            document.querySelectorAll('[required]').forEach(function(field) {
                field.addEventListener('blur', function() {
                    validateField(this);
                });
                
                field.addEventListener('change', function() {
                    validateField(this);
                });
            });
            
            // Form validation on submit
            const form = document.getElementById('orderForm');
            
            // Handle delivery type changes
            const deliveryTypeInputs = document.querySelectorAll('input[name="delivery_type"]');
            const dateLabel = document.getElementById('date_label');
            const timeLabel = document.getElementById('time_label');
            const deliveryAddress = document.getElementById('delivery_address');
            const deliveryAddressRequired = document.getElementById('delivery_address_required');
            
            deliveryTypeInputs.forEach(function(input) {
                input.addEventListener('change', function() {
                    const isDelivery = this.value === 'delivery';
                    dateLabel.textContent = isDelivery ? 'Delivery' : 'Self Collect';
                    timeLabel.textContent = isDelivery ? 'Delivery' : 'Self Collect';
                    if (isDelivery) {
                        deliveryAddress.setAttribute('required', 'required');
                        deliveryAddressRequired.style.display = '';
                    } else {
                        deliveryAddress.removeAttribute('required');
                        deliveryAddressRequired.style.display = 'none';
                        deliveryAddress.classList.remove('is-invalid');
                    }
                });
            });
            
            // Handle Save Order button click - show confirmation modal instead of direct submit
            document.getElementById('saveOrderBtn').addEventListener('click', function() {
                // First validate the form
                let errors = [];
                
                const requiredFields = form.querySelectorAll('[required]');
                requiredFields.forEach(function(field) {
                    if (!validateField(field)) {
                        let fieldName = field.getAttribute('placeholder') || 
                                       field.previousElementSibling?.textContent || 
                                       'Field';
                        fieldName = fieldName.replace(/\*|\(.*?\)/g, '').trim();
                        errors.push(`${fieldName} is required.`);
                    }
                });
                
                const productItems = document.querySelectorAll('.order-item');
                if (productItems.length === 0) {
                    errors.push('You need at least one product item.');
                } else {
                    productItems.forEach(function(item, index) {
                        const productType = item.querySelector('select');
                        const productQuantity = item.querySelector('input[type="number"]');
                        
                        if (!productType.value) {
                            errors.push(`Product #${index + 1}: Type is required.`);
                        }
                        
                        if (!productQuantity.value || productQuantity.value < 1) {
                            errors.push(`Product #${index + 1}: Quantity must be at least 1.`);
                        }
                    });
                }
                
                if (errors.length > 0) {
                    showValidationAlert(errors);
                    form.classList.add('was-validated');
                    return;
                }

                // If validation passes, populate and show confirmation modal
                populateConfirmationModal();
                const modal = new bootstrap.Modal(document.getElementById('orderConfirmationModal'));
                modal.show();
            });

            // Handle confirmation modal confirm button
            document.getElementById('confirmOrderBtn').addEventListener('click', function() {
                // Disable the button to prevent double submission
                this.disabled = true;
                this.innerHTML = '<i class="ri-loader-4-line me-1 spinner-border spinner-border-sm"></i>Processing...';
                
                // Hide the modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('orderConfirmationModal'));
                modal.hide();
                
                // Submit the form
                form.submit();
            });

            // Function to populate confirmation modal with order details
            function populateConfirmationModal() {
                // Customer Information
                document.getElementById('confirm-customer-name').textContent = 
                    document.getElementById('customer_name').value || '-';
                document.getElementById('confirm-customer-phone').textContent = 
                    document.getElementById('customer_phone').value || '-';
                document.getElementById('confirm-customer-email').textContent = 
                    document.getElementById('customer_email').value || 'Not provided';
                document.getElementById('confirm-customer-address').textContent = 
                    document.getElementById('customer_address').value || '-';

                // Order Items
                const orderItemsContainer = document.getElementById('confirm-order-items');
                orderItemsContainer.innerHTML = '';
                
                const productItems = document.querySelectorAll('.order-item');
                productItems.forEach(function(item, index) {
                    const productType = item.querySelector('select').value;
                    const patientName = item.querySelector('.patient-name-field').value;
                    const quantity = item.querySelector('input[type="number"]').value;
                    const remarks = item.querySelector('.remarks-field').value;
                    const coaRequired = item.querySelector('input[type="checkbox"]').checked;
                    
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'mb-3 pb-3';
                    if (index < productItems.length - 1) {
                        itemDiv.className += ' border-bottom';
                    }
                    
                    itemDiv.innerHTML = `
                        <div class="row">
                            <div class="col-md-5">
                                <strong>Product:</strong> ${productType || '-'}
                            </div>
                            <div class="col-md-2">
                                <strong>Quantity:</strong> ${quantity || '-'}
                            </div>
                            <div class="col-md-3">
                                <strong>Patient:</strong> ${patientName || 'Not specified'}
                            </div>
                            <div class="col-md-2">
                                <strong>COA:</strong> ${coaRequired ? '<span class="badge bg-success">Required</span>' : '<span class="badge bg-secondary">Not Required</span>'}
                            </div>
                        </div>
                        ${remarks ? `<div class="row mt-1"><div class="col-12"><strong>Remarks:</strong> ${remarks}</div></div>` : ''}
                    `;
                    
                    orderItemsContainer.appendChild(itemDiv);
                });

                // Delivery Information
                const deliveryType = document.querySelector('input[name="delivery_type"]:checked').value;
                document.getElementById('confirm-delivery-type').textContent = 
                    deliveryType === 'delivery' ? 'Delivery' : 'Self Collect';
                
                // Time Sensitive
                const timeSensitive = document.getElementById('time_sensitive').checked;
                const timeSensitiveSpan = document.getElementById('confirm-time-sensitive');
                if (timeSensitive) {
                    timeSensitiveSpan.textContent = 'Yes';
                    timeSensitiveSpan.className = 'badge bg-danger';
                } else {
                    timeSensitiveSpan.textContent = 'No';
                    timeSensitiveSpan.className = 'badge bg-secondary';
                }
                
                document.getElementById('confirm-delivery-date').textContent = 
                    document.getElementById('pickup_delivery_date').value || '-';
                document.getElementById('confirm-delivery-time').textContent = 
                    document.getElementById('pickup_delivery_time').value || '-';
                document.getElementById('confirm-item-ready').textContent = 
                    document.getElementById('item_ready_at').value || '-';
                document.getElementById('confirm-collection-date').textContent = 
                    document.getElementById('collection_date').value || 'Not specified';
                document.getElementById('confirm-collection-time').textContent = 
                    document.getElementById('collection_time').value || 'Not specified';
                document.getElementById('confirm-delivery-address').textContent = 
                    document.getElementById('delivery_address').value || 'Not specified';

                // General Remarks
                const generalRemarks = document.getElementById('remarks').value;
                document.getElementById('confirm-general-remarks').textContent = 
                    generalRemarks || 'No remarks';
            }
        });
    </script>
@endsection
